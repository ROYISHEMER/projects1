import React, { Component } from "react";

export default class CCCalc extends Component {
    constructor(props) {
        super(props);
        this.state = {
            num1: 0,
            num2: 0,
            sum: null,
        };
    }

    updateNum1 = (e) => {
        this.setState({ num1: Number(e.target.value) });
    };

    updateNum2 = (e) => {
        this.setState({ num2: Number(e.target.value) });
    };
    performSubtraction = () => {
        const { num1, num2 } = this.state;
        console.log("num1:", num1, "num2:", num2);
        this.setState({ result: num1 - num2 });
    };

    performAddition = () => {
        const { num1, num2 } = this.state;
        console.log("num1:", num1, "num2:", num2);
        this.setState({ result: num1 + num2 });
    };
  
    performMultiplication = () => {
        const { num1, num2 } = this.state;
        console.log("num1:", num1, "num2:", num2);
        this.setState({ result: num1 * num2 });
    };

    performDivision = () => {
        const { num1, num2 } = this.state;
        console.log("num1:", num1, "num2:", num2);
        this.setState({ result: num1 / num2 });
    };

    render() {
        const { result } = this.state;

        return (
            <div>
                <div>
                    Number1:
                     <input type="num1" onChange={this.updateNum1} /><br />

                    Number2:
                     <input type="num2" onChange={this.updateNum2} /> <br /> <br />


                    <button onClick={this.performSubtraction}>-</button><br />
                    <button onClick={this.performAddition}>+</button>
                    <button onClick={this.performMultiplication}>*</button>
                    <button onClick={this.performDivision}>/</button>

                </div><br /><br />
                The Result:
                 <input type="number" value={result} readOnly />
                <br />
            </div>
        );
    }
}
